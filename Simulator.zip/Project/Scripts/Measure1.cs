﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Measure1 : MonoBehaviour
{

    public Button Result1, naPuskB, anotherBut;
    public GameObject manometerOk1_1, manometerOk2_1, 
    manometerOk3_1, manometerOk4_1, man5, man6, 
    gaz1_1, gaz2_1, 
    rac1, rac2, rac3,
    manomArrow1, opencam1, opencam2, 
    oy, alarmD, cran1, cran2;
    Vector3 StartPos;
    string m, m1, m2, m3, m4, m5, m6, m7, m8, m10, m11,
    m12, m13, m14, m15, m16, m17, m18, m19,
    m20, m21, m22;
    public float timeRemaining = 0.0f;
    public static float endTime1 = 0.0f;
    public static List<string> PuskRes = new List<string>
    {
        "Результаты пуска"
    };

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {
        timeRemaining += Time.deltaTime;
    }
    private static Quaternion Change(float x, float y, float z, float w)
    {
        //Return the new Quaternion
        return new Quaternion(x, y, z, w);
    }
    public void TakeAnalyz1()
    {
        m1 = "Показатель газоанализатора 1.0 г/м3";
        PuskRes.Add(m1);
    }
    public void TakeManometer1()
    {
        m2 = "Давление в манометре 0.0 МПа";
        manometerOk1_1.SetActive(false);
        manometerOk2_1.SetActive(true);
        PuskRes.Add(m2);
    }
    public void NaPusk()
    {
        m10 = "Перевод на пуск";
        StartPos = alarmD.transform.position;
        StartPos.y = 11.3f;
        alarmD.transform.position = StartPos;
        naPuskB.interactable = false;
        anotherBut.interactable = true;
        PuskRes.Add(m10);
    }
    public void TakeDrenajDisp()
    {
        m11 = "Уровень жидкости в дренажной емкости 1.0";
        rac1.SetActive(false);
        rac2.SetActive(true);
        PuskRes.Add(m11);
    }
    public void TakeManometer2()
    {
        m2 = "Давление в манометре 0.0 МПа";
        manometerOk2_1.SetActive(false);
        manometerOk3_1.SetActive(true);
        PuskRes.Add(m2);
    }
    public void OpenDrenCran()
    {
        m11 = "Открыт дренажный кран";
        PuskRes.Add(m11);
    }
    public void OpenCran()
    {
        m12 = "Открыт кран для стравливания";
        cran1.SetActive(false);
        cran2.SetActive(true);
        PuskRes.Add(m12);
    }
    public void TakeShyp1()
    {
        m4 = "Уровень жидкости в камере 4.0";
        PuskRes.Add(m4);
    }
    public void OpenCamera()
    {
        m13 = "Открыта камера";
        //oy.SetActive(false);
        PuskRes.Add(m13);
    }
    public void TakeAnalyz2()
    {
        m5 = "Показатель газоанализатора 1.0 г/м3";
        gaz1_1.SetActive(false);
        gaz2_1.SetActive(true);
        PuskRes.Add(m5);
    }
    public void CloseCamera()
    {
        m14 = "Закрыта камера";
        opencam1.SetActive(false);
        opencam2.SetActive(true);
        //oy.SetActive(true);
        PuskRes.Add(m14);
    }
    public void Close14()
    {
        m15 = "Задвижка №14 закрыта";
        PuskRes.Add(m15);
    }
    public void Disp1()
    {
        m = "Сообщение о готовности";
        rac2.SetActive(false);
        rac3.SetActive(true);
        PuskRes.Add(m);
    }
    public void Open7()
    {
        m15 = "Задвижка №7 приоткрыта";
        PuskRes.Add(m15);
    }
    public void CloseCran()
    {
        m16 = "Кран для стравливания закрыт";
        manomArrow1.transform.rotation = Change(0.0f, 0.0f, 0.0f, 1.0f);
        PuskRes.Add(m16);
    }
    public void TakeManometer3()
    {
        m6 = "Давление в манометре 5.0 МПа";
        manometerOk3_1.SetActive(false);
        manometerOk4_1.SetActive(true);
        PuskRes.Add(m6);
    }
    public void TakeManometer4()
    {
        m7 = "Давление в манометре 0.0 МПа";
        PuskRes.Add(m7);
    }
    public void Open7Open()
    {
        m17 = "Задвижка №7 открыта";
        PuskRes.Add(m17);
    }
    public void Open4()
    {
        m18 = "Задвижка №4 открыта";
        PuskRes.Add(m18);
    }
    public void Close2()
    {
        m19 = "Задвижка №2 закрыта";
        StartPos = alarmD.transform.position;
        StartPos.y = 11.4f;
        alarmD.transform.position = StartPos;
        naPuskB.interactable = true;
        anotherBut.interactable = false;
        //manomArrow1.transform.rotation = Change(0.0f, 0.0f, -0.9f, 0.5f);
        PuskRes.Add(m19);
    }
    public void TakeManometer5()
    {
        m8 = "Давление в манометре 5.5 МПа";
        man5.SetActive(false);
        man6.SetActive(true);
        PuskRes.Add(m8);
    }

    public void Open2()
    {
        m20 = "Задвижка №2 открыта";
        PuskRes.Add(m20);
    }
    public void Close7()
    {
        m21 = "Задвижка №7 закрыта";
        PuskRes.Add(m21);
    }
    public void Close4()
    {
        m22 = "Задвижка №4 закрыта";
        manomArrow1.transform.rotation = Change(0.0f, 0.0f, -0.9f, 0.5f);
        cran1.SetActive(false);
        cran2.SetActive(true);
        endTime1 = timeRemaining;
        PuskRes.Add(m22);
        Result1.interactable = true;
    }
    public void OpenCran1()
    {
        m1 = "Открыт кран для стравливания";
        PuskRes.Add(m1);
    }
    public void TakeManometer6()
    {
        m = "Давление в манометре 0.0 МПа";
        PuskRes.Add(m);
    }
    public void CloseCran1()
    {
        m = "Кран для стравливания закрыт";      
        PuskRes.Add(m);
    }
    public static List<string> PuskCheck = new List<string>
    {
        "Результаты пуска",
        "Показатель газоанализатора 1.0 г/м3",
        "Давление в манометре 0.0 МПа",
        "Перевод на пуск",
        "Уровень жидкости в дренажной емкости 1.0",
        "Давление в манометре 0.0 МПа",
        "Открыт дренажный кран",
        "Открыт кран для стравливания",
        "Уровень жидкости в камере 4.0",
        "Открыта камера",
        "Показатель газоанализатора 1.0 г/м3",
        "Закрыта камера",
        "Задвижка №14 закрыта",
        "Сообщение о готовности",
        "Задвижка №7 приоткрыта",
        "Кран для стравливания закрыт",
        "Давление в манометре 5.0 МПа",
        "Давление в манометре 0.0 МПа",
        "Задвижка №7 открыта",
        "Задвижка №4 открыта",
        "Задвижка №2 закрыта",
        "Давление в манометре 5.5 МПа",
        "Задвижка №2 открыта",
        "Задвижка №7 закрыта",
        "Задвижка №4 закрыта",
        "Открыт дренажный кран",
        "Открыт кран для стравливания",
        "Давление в манометре 0.0 МПа",
        "Задвижка №14 закрыта",
        "Кран для стравливания закрыт"
    };
}
