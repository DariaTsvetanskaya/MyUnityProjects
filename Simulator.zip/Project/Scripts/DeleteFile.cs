﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class DeleteFile : MonoBehaviour {

	// Use this for initialization
	void Start () {
        if (!Directory.Exists("Save")) {
            Directory.CreateDirectory("Save");
        }


        if (!File.Exists("Save/result.txt")) {
            File.Create("Save/result.txt");
        }
        else {
            File.Delete("Save/result.txt");
            File.Create("Save/result.txt");
        }

    }
    // Update is called once per frame
    void Update () {
		
	}

    /*static DeleteFile()
    {
        ProcessDirectory("Save/");
    }

    public static void ProcessDirectory(string targetDirectory)
    {
        // Process the list of files found in the directory.
        string[] fileEntries = Directory.GetFiles(targetDirectory);
        foreach (string filePath in fileEntries)
        {
            FileInfo fileInfo = new FileInfo(filePath);

            if (fileInfo.Name == "result.txt")
            {
                ProcessFile(filePath);
            }
        }

        // Recurse into subdirectories of this directory.
        string[] subdirectoryEntries = Directory.GetDirectories(targetDirectory);
        foreach (string subdirectory in subdirectoryEntries)
        {
            ProcessDirectory(subdirectory);
        }
    }

    // Insert logic for processing found files here.
    public static void ProcessFile(string path)
    {
        Debug.Log("Processed file " + path);

        //Delete File
    }*/
}
