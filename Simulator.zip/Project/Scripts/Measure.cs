﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Measure : MonoBehaviour {

    public Button Result, NaPriemB, AnotherB, Open, Close;
    public GameObject deflate, manometerOk1, manometerOk2, manometerOk3, 
    manomArrow, oy, alarmD, cap,  
    gaz1, gaz2, gaz3, 
    shyp1, shyp2, 
    opencam1, opencam2, 
    opencran1, opencran2,
    disp1, disp2,
    closeCam1, closeCam2;
    Vector3 StartPos, oyStartPos;
    Quaternion StartRot;
    public float timeRemaining = 0.0f;
    string m, m2, m3, m4, m5, m6, m7, m8, m9, 
    m10, m11, m12, m13, m14, m15, m16, m17, m18,
    m19, m20, m21, m22, m23, m24, m25, m26;
    public static float endTime = 0.0f;

    public static List<string> AllResult = new List<string>
    {
        "Результаты приема"
    };
    // Use this for initialization
    void Start () {
		
	}
    private static Quaternion Change(float x, float y, float z, float w)
    {
        //Return the new Quaternion
        return new Quaternion(x, y, z, w);
    }
    // Update is called once per frame
    void Update () {
        timeRemaining += Time.deltaTime;
        //Debug.Log(manomArrow.transform.rotation);
    }
    public void TakeAnalyz1() {
        m = "Показатель газоанализатора 1.0 г/м3";
        gaz1.SetActive(false);
        gaz2.SetActive(true);
        //AllResult.Insert(2, m1);
        AllResult.Add(m);
    }
    public void TakeManometer1()
    {
        m2 = "Давление в манометре 0.0 МПа";
        manometerOk1.SetActive(false);
        manometerOk2.SetActive(true);
        AllResult.Add(m2);
    }
    public void NaPriem()
    {
        m12 = "Перевод на прием";
        StartPos = alarmD.transform.position;
        StartPos.y = 11.3f;
        alarmD.transform.position = StartPos;
        NaPriemB.interactable = false;
        AnotherB.interactable = true;
        AllResult.Add(m12);
    }
    public void TakeDrenaj1() {
        m3 = "Уровень жидкости в дренажной емкости 8.0";
        deflate.SetActive(true);
        AllResult.Add(m3);
    }
    public void TakeManometer2()
    {
        m4 = "Давление в манометре 0.0 МПа";
        manometerOk2.SetActive(false);
        manometerOk3.SetActive(true);
        AllResult.Add(m4);
    }
    public void OpenDrenCran()
    {
        m11 = "Открыт дренажный кран";
        AllResult.Add(m11);
    }
    public void OpenCran()
    {
        m13 = "Открыт кран для стравливания";

        AllResult.Add(m13);
    }  
    public void TakeShyp1() {
        m5 = "Уровень жидкости в камере 5.5";
        shyp1.SetActive(false);
        shyp2.SetActive(true);
        AllResult.Add(m5);
    }
    public void OpenCamera()
    {
        m14 = "Открыта камера";
        oy.SetActive(false);
        AllResult.Add(m14);
    }
    public void TakeAnalyz2()
    {
        m6 = "Показатель газоанализатора 1.1 г/м3";
        gaz2.SetActive(false);
        gaz3.SetActive(true);
        AllResult.Add(m6);
    }
    public void CloseCamera()
    {
        m25 = "Закрыта камера";
        opencam1.SetActive(false);
        opencam2.SetActive(true);
        AllResult.Add(m25);
    }
    public void Close13()
    {
        m15 = "Задвижка №13 закрыта";
        AllResult.Add(m15);
    }
    public void Open5a()
    {
        m16 = "Задвижка №5a открыта";
        AllResult.Add(m16);
    }
    public void Open5()
    {
        m17 = "Задвижка №5 приоткрыта";
        AllResult.Add(m17);
    }
    public void CloseCran()
    {
        m18 = "Кран для стравливания закрыт";
        manomArrow.transform.rotation = Change(0.0f, 0.0f, 0.0f, 1.0f);
        opencran1.SetActive(false);
        opencran2.SetActive(true);
        AllResult.Add(m18);
    }
    public void TakeManometer3()
    {
        m7 = "Давление в манометре 5.5 МПа";
        AllResult.Add(m7);
    }
    public void TakeManometer4()
    {
        m8 = "Давление в манометре 0.0 МПа";
        disp1.SetActive(false);
        disp2.SetActive(true);
        AllResult.Add(m8);
    }
    public void Open3()
    {
        m19 = "Задвижка №3 открыта";
        AllResult.Add(m19);
    }
    public void Close1()
    {
        m20 = "Задвижка №1 закрыта";
        //сигнализатор
        StartPos = alarmD.transform.position;
        StartPos.y = 11.4f;
        alarmD.transform.position = StartPos;
        NaPriemB.interactable = true;
        AnotherB.interactable = false;

        AllResult.Add(m20);
    }
    public void Disp1()
    {
        m = "Сообщение о готовности";
        AllResult.Add(m);
    }
    public void Open1()
    {
        m21 = "Задвижка №1 октрыта";
        AllResult.Add(m21);
    }
    public void Close3()
    {
        m22 = "Задвижка №3 закрыта";
        AllResult.Add(m22);
    }
    public void Close5a()
    {
        m23 = "Задвижка №5a закрыта";
        AllResult.Add(m23);
    }
    public void Close5()
    {
        m24 = "Задвижка №5 закрыта";
        AllResult.Add(m24);
        manomArrow.transform.rotation = Change(0.0f, 0.0f, -0.9f, 0.5f);
    }
    public void OpenCran2()
    {
        m26 = "Открыт кран для стравливания";
       
        AllResult.Add(m26);
    }
    public void TakeShyp2()
    {
        m9 = "Уровень жидкости в камере 0.4";
        AllResult.Add(m9);
    }
    public void OpenCamera2()
    {
        m14 = "Открыта камера";
        closeCam1.SetActive(false);
        closeCam2.SetActive(true);
        oy.SetActive(true);
        AllResult.Add(m14);
    }
    public void TakeAnalyz3()
    {
        m = "Показатель газоанализатора 1.3 г/м3";
        AllResult.Add(m);
        endTime = timeRemaining;
        Result.interactable = true;
    }
    public void CloseCamera2()
    {
        m = "Закрыта камера";
        StartPos = cap.transform.position;
        StartRot = cap.transform.rotation;
        StartPos.z = 20.0f;

        StartRot.y = 0.0f;
        StartRot.w = -1.0f;

        cap.transform.position = StartPos;
        cap.transform.rotation = StartRot;

        Open.interactable = true;
        Close.interactable = false;
        AllResult.Add(m);
    }
    public static List<string> Check = new List<string>
    {
        "Результаты приема",
        "Тест пройден успешно",
        "Показатель газоанализатора 1.0 г/м3",
        "Давление в манометре 0.0 МПа",
        "Перевод на прием",
        "Уровень жидкости в дренажной емкости 8.0",
        "Давление в манометре 0.0 МПа",
        "Открыт дренажный кран",
        "Открыт кран для стравливания",
        "Уровень жидкости в камере 5.5",
        "Открыта камера",
        "Показатель газоанализатора 1.1 г/м3",
        "Закрыта камера",
        "Задвижка №13 закрыта",
        "Задвижка №5a открыта",
        "Задвижка №5 приоткрыта",
        "Кран для стравливания закрыт",
        "Давление в манометре 5.5 МПа",
        "Давление в манометре 0.0 МПа",
        "Задвижка №3 открыта",
        "Задвижка №1 закрыта",
        "Сообщение о готовности",
        "Задвижка №1 октрыта",
        "Задвижка №3 закрыта",
        "Задвижка №5a закрыта",
        "Задвижка №5 закрыта",
        "Открыт дренажный кран",
        "Открыт кран для стравливания",
        "Уровень жидкости в камере 0.4",
        "Открыта камера",
        "Показатель газоанализатора 1.3 г/м3",
        "Закрыта камера",
        "Сообщение о готовности"
    };
}
