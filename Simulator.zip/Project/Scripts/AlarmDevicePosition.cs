﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class AlarmDevicePosition : MonoBehaviour
{

    public Button NaPriem, AnotherB;
    public GameObject alarmDevice;
    Vector3 StartPosition;
    // Use this for initialization
    void Start()
    {
        StartPosition = alarmDevice.transform.position;
        //NaPriem.onClick.AddListener(ChangePosition);
        AnotherB.onClick.AddListener(ChangePosition);
    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log(StartPosition);
    }

    public void ChangePosition()
    {
        if (NaPriem.interactable)
        {
            StartPosition.y = 11.4f;
            alarmDevice.transform.position = StartPosition;
            NaPriem.interactable = false;
            AnotherB.interactable = true;
        }
        else
        {
            StartPosition.y = 11.4f;
            alarmDevice.transform.position = StartPosition;
            NaPriem.interactable = true;
            AnotherB.interactable = false;
        }
    }
}
