﻿using System.Collections;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

public class GazAnalyzerShow : MonoBehaviour {

    public GameObject GA;
    // Use this for initialization
	void Start () {
        string three = "3";
            string readText = File.ReadAllText("Save/menutask1.txt");
        if (readText.Contains(three))
        {
            GA.SetActive(true);
        }
    }
	
	// Update is called once per frame
	void Update () {
	}
    //string[] readText = File.ReadAllLines("Save/menutask1.txt");
}
