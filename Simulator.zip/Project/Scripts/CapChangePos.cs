﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CapChangePos : MonoBehaviour {
    public GameObject oy, basket, cap;
    public Button Open, Close;
    Vector3 startPos, oyStartPos, basketStartPos;
    Quaternion startRot;
    // Use this for initialization
	void Start () {
        //Open.onClick.AddListener(CapChangePosition);
        //Close.onClick.AddListener(CapChangePosition);
	}
	
	// Update is called once per frame
	void Update () {
        //Debug.Log(basket.transform.position);
        //Debug.Log(transform.position);
        //Debug.Log(transform.rotation);
	}

    public void CapChangePosition() {
        if (Open.interactable) {
            startPos = cap.transform.position;
            oyStartPos = oy.transform.position;
            basketStartPos = basket.transform.position;
            startRot = cap.transform.rotation;

            startPos.z = 17.4f;
            basketStartPos.x = -16.0f;
            oyStartPos.x = -13.5f;

            startRot.y = 0.9f;
            startRot.w = -0.4f;

            cap.transform.position = startPos;
            oy.transform.position = oyStartPos;
            basket.transform.position = basketStartPos;
            cap.transform.rotation = startRot;

            Open.interactable = false;
            Close.interactable = true;
        }
        else {
            startPos = cap.transform.position;
            oyStartPos = oy.transform.position;
            basketStartPos = basket.transform.position;
            startRot = cap.transform.rotation;


            startPos.z = 20.0f;
            basketStartPos.x = -28.2f;
            oyStartPos.x = -25.5f;

            startRot.y = 1.0f;
            startRot.w = 0.0f;

            cap.transform.position = startPos;
            oy.transform.position = oyStartPos;
            basket.transform.position = basketStartPos;
            cap.transform.rotation = startRot;

            Open.interactable = true;
            Close.interactable = false;
        }
    }
}
