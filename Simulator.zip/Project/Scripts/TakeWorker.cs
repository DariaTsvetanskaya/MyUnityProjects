﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class TakeWorker : MonoBehaviour {

    public GameObject Worker, FPS;
    Vector3 StartPos;
    Quaternion StartRot;
    // Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
        //Debug.Log(Worker.transform.position);
        //Debug.Log(Worker.transform.rotation);
    }
    //Invoked when a button is pressed.
    public void Example()
    {
        //Makes the GameObject "newParent" the parent of the GameObject "player".
        Worker.transform.parent = FPS.transform;
        StartPos = Worker.transform.position;
        StartPos.z += 1.5f;
        Worker.transform.position = StartPos;
        StartRot = Worker.transform.rotation;
        StartRot.y += 90.0f;
        Worker.transform.rotation = StartRot;
    }
}
