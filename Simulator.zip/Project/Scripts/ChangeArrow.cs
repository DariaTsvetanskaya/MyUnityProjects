﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeArrow : MonoBehaviour {

    public GameObject Arrow6, Arrow61, ArrowRed6, ArrowRed61,
        Arrow4, Arrow41, ArrowRed4, ArrowRed41,
        Arrow7, Arrow71, ArrowRed7, ArrowRed71,
        Arrow3, Arrow31, ArrowRed3, ArrowRed31,
        Arrow11, ArrowRed11,
        Arrow5, Arrow51, ArrowRed5, ArrowRed51;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
        //Debug.Log(Arrow6.transform.rotation);
        //Debug.Log(Arrow4.transform.rotation);
        //Debug.Log(Arrow7.transform.rotation);
        //Debug.Log(Arrow3.transform.rotation);
    }
    private static Quaternion Change(float x, float y, float z, float w)
    {
        //Return the new Quaternion
        return new Quaternion(x, y, z, w);
    }
    public void OpenUp5() {
        ArrowRed6.SetActive(false);
        ArrowRed61.SetActive(false);
        Arrow6.SetActive(true);
        Arrow61.SetActive(true);

        ArrowRed4.SetActive(false);
        ArrowRed41.SetActive(false);
        Arrow4.SetActive(true);
        Arrow41.SetActive(true);

        ArrowRed7.SetActive(false);
        ArrowRed71.SetActive(false);
        Arrow7.SetActive(true);
        Arrow71.SetActive(true);

        ArrowRed3.SetActive(false);
        ArrowRed31.SetActive(false);
        Arrow3.SetActive(true);
        Arrow31.SetActive(true);
    }

    public void Open3() {
        ArrowRed11.SetActive(false);
        Arrow11.SetActive(true);

        Arrow6.transform.rotation = Change(0.0f, 0.7f, 0.0f, 0.7f);
        Arrow6.transform.rotation = Change(0.0f, 0.7f, 0.0f, 0.7f);
        Arrow4.transform.rotation = Change(0.0f, 1.0f, 0.0f, 0.0f);
        Arrow41.transform.rotation = Change(0.0f, 1.0f, 0.0f, 0.0f);
        Arrow7.transform.rotation = Change(0.0f, 1.0f, 0.0f, 0.0f);
        Arrow71.transform.rotation = Change(0.0f, 1.0f, 0.0f, 0.0f);
        Arrow3.transform.rotation = Change(0.0f, -0.7f, 0.0f, 0.7f);
        Arrow31.transform.rotation = Change(0.0f, -0.7f, 0.0f, 0.7f);
    }

    public void Close1() {
        ArrowRed5.SetActive(true);
        ArrowRed51.SetActive(true);
        Arrow5.SetActive(false);
        Arrow51.SetActive(false);
    }
    public void Open1()
    {
        ArrowRed5.SetActive(false);
        ArrowRed51.SetActive(false);
        Arrow5.SetActive(true);
        Arrow51.SetActive(true);
    }
    public void Close5() {
        ArrowRed11.SetActive(true);
        Arrow11.SetActive(false);

        ArrowRed6.SetActive(true);
        ArrowRed61.SetActive(true);
        Arrow6.SetActive(false);
        Arrow61.SetActive(false);

        ArrowRed4.SetActive(true);
        ArrowRed41.SetActive(true);
        Arrow4.SetActive(false);
        Arrow41.SetActive(false);

        ArrowRed7.SetActive(true);
        ArrowRed71.SetActive(true);
        Arrow7.SetActive(false);
        Arrow71.SetActive(false);

        ArrowRed3.SetActive(true);
        ArrowRed31.SetActive(true);
        Arrow3.SetActive(false);
        Arrow31.SetActive(false);
    }


}
