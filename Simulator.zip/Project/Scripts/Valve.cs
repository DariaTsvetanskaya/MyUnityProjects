﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Valve : MonoBehaviour
{

    public Button Open, OpenUp, Close;
    public GameObject valve, target;
    Quaternion valveStartRot;
    // Use this for initialization
    void Start()
    {
        Open.onClick.AddListener(ValveRotate1);
        OpenUp.onClick.AddListener(ValveRotate2);
        Close.onClick.AddListener(ValveRotate3);
    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log(valve.transform.rotation);
        target = GameObject.Find("FPSController");
        transform.LookAt(target.transform);
    }

    public void ValveRotate1()
    {
        valveStartRot = valve.transform.rotation;
        valveStartRot.y += 0.9f;
        valve.transform.rotation = valveStartRot;

        Open.interactable = false;
        OpenUp.interactable = true;
        Close.interactable = true;
    }
    public void ValveRotate2()
    {
        valveStartRot = valve.transform.rotation;
        valveStartRot.y += 0.9f;
        valve.transform.rotation = valveStartRot;

        Open.interactable = true;
        OpenUp.interactable = false;
        Close.interactable = true;
    }
    public void ValveRotate3()
    {
        valveStartRot = valve.transform.rotation;
        valveStartRot.y -= 0.9f;
        valve.transform.rotation = valveStartRot;

        Open.interactable = true;
        OpenUp.interactable = true;
        Close.interactable = false;
    }
}
