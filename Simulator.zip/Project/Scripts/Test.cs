﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Test : MonoBehaviour {

    public Toggle toggle1, toggle2, toggle3, toggle4, toggle5, toggle6, toggle7;
    public Button Ok;
    // Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    public void CheckTest() {
        if ((toggle1.isOn) && !(toggle2.isOn) && (toggle4.isOn) &&
            !(toggle5.isOn) && (toggle6.isOn) && (toggle7.isOn))
        {
            Measure.AllResult.Insert(1, "Тест пройден успешно");
            Ok.interactable = false;
        }
        else
        {
            Measure.AllResult.Insert(1, "В тесте были ошибки");
            Ok.interactable = false;
        }
    }
}
