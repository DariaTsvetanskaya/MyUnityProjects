﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ManometerChange : MonoBehaviour {

    public Image m_Image;
    public Button buttonOk, buttonChange;
    //Set this in the Inspector
    public Sprite Manometer, ManometerBroken;
    // Use this for initialization
    void Start () {
        //Fetch the Image from the GameObject
        m_Image = GetComponent<Image>();
        buttonChange.onClick.AddListener(ButtonChange);
    }
	
	// Update is called once per frame
	void Update () {
		
	}
    //если манометр в порядке, то 
    public void ButtonOk() {
    }
    //если нет
    public void ButtonChange() {
        if (m_Image.sprite == ManometerBroken) {
            m_Image.sprite = Manometer;
            buttonOk.interactable = true;
            buttonChange.interactable = false;
        }
    }
}