﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoOver : MonoBehaviour {

    public GameObject player;
    public GameObject floor1;
    Vector3 startPos;
    // Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {

	}
    public void GoOverOnClick() {
        floor1.SetActive(false);
        //startPos = player.transform.position;
        startPos.x = 6.0f;
        startPos.y = 1.6f;
        startPos.z = 28.0f;
        player.transform.position = startPos;
    }
    public void GoOverOnClickBack()
    {
        floor1.SetActive(true);
        //startPos = player.transform.position;
        startPos.x = 6.0f;
        startPos.y = 9f;
        startPos.z = 28.0f;
        player.transform.position = startPos;
    }

}
