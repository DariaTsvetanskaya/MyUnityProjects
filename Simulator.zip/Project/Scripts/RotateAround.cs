﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class RotateAround : MonoBehaviour {

    public GameObject Shyp, rotor;
    public Button Up, Down;
    public Toggle grounded;
    
    // Use this for initialization
	void Start () {
        //Up.onClick.AddListener(ChangePos);
        //Down.onClick.AddListener(ChangePos);
	}
	
	// Update is called once per frame
	void Update () {
        //Debug.Log(rotor.transform.position);
        //Debug.Log(rotor.transform.rotation);
    }
    private static Quaternion Change(float x, float y, float z, float w)
    {
        //Return the new Quaternion
        return new Quaternion(x, y, z, w);
    }
    private static Vector3 ChangeV(float x, float y, float z)
    {
        //Return the new Quaternion
        return new Vector3(x, y, z);
    }
    public void ChangePos() {
        //if (grounded.isOn) {

        //}
        if (Down.interactable)
        {
            //Shyp.SetActive(true);
            rotor.transform.position = ChangeV(11.35f, 11.0f, 20.0f);
            rotor.transform.rotation = Change(0.0f, 0.0f, 0.0f, 1.0f);


            Down.interactable = false;
            Up.interactable = true;
        }
        else
        {
            //Shyp.SetActive(false);
            rotor.transform.position = ChangeV(11.35f, 11.8f, 19.6f);
            rotor.transform.rotation = Change(0.7f, 0.0f, 0.0f, 0.7f);
            Down.interactable = true;
            Up.interactable = false;
        }
    }

    public void Pos()
    {
        //if (grounded.isOn) {

        //}
        if (Down.interactable)
        {
            //Shyp.SetActive(true);
            rotor.transform.position = ChangeV(-30.15f, 11.0f, 20.0f);
            rotor.transform.rotation = Change(0.0f, 0.0f, 0.0f, 1.0f);


            Down.interactable = false;
            Up.interactable = true;
        }
        else
        {
            //Shyp.SetActive(false);
            rotor.transform.position = ChangeV(-30.15f, 11.8f, 19.6f);
            rotor.transform.rotation = Change(0.7f, 0.0f, 0.0f, 0.7f);
            Down.interactable = true;
            Up.interactable = false;
        }
    }
}
