﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class CapChangePos1 : MonoBehaviour
{
    public GameObject basket, oy, cap;
    public Button Open, Close;
    Vector3 startPos, basketStartPos, oyStartPos;
    Quaternion startRot;
    // Use this for initialization
    void Start()
    {
        //Open.onClick.AddListener(CapChangePosition);
        //Close.onClick.AddListener(CapChangePosition);
    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log(transform.position);
        //Debug.Log(transform.rotation);
    }

    public void CapChangePosition()
    {
        if (Open.interactable)
        {
            startPos = cap.transform.position;
            oyStartPos = oy.transform.position;
            basketStartPos = basket.transform.position;
            startRot = cap.transform.rotation;

            startPos.z = 18.1f;
            basketStartPos.x -= 13.5f;
            oyStartPos.x = -4.5f;

            startRot.y = 0.7f;
            startRot.w = -0.8f;

            cap.transform.position = startPos;
            oy.transform.position = oyStartPos;
            basket.transform.position = basketStartPos;
            cap.transform.rotation = startRot;

            Open.interactable = false;
            Close.interactable = true;
        }
        else
        {
            startPos = cap.transform.position;
            oyStartPos = oy.transform.position;
            basketStartPos = basket.transform.position;
            startRot = cap.transform.rotation;
            startPos.z = 20.0f;
            oyStartPos.x = 9.0f;
            basketStartPos.x += 13.5f;

            startRot.y = 0.0f;
            startRot.w = -1.0f;

            cap.transform.position = startPos;
            oy.transform.position = oyStartPos;
            basket.transform.position = basketStartPos;
            cap.transform.rotation = startRot;

            Open.interactable = true;
            Close.interactable = false;
        }
    }
}
