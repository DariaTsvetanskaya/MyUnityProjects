﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using System.Linq;

public class ShowResultPusk : MonoBehaviour
{
    public Text resultPr, resultPusk;
    float endTime = 0.0f;
    private string text = "", text2 = "";
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }
    public void AddResult()
    {
        bool equal = Measure1.PuskCheck.SequenceEqual(Measure1.PuskRes);
        if (equal == true)
        {
            endTime = Measure1.endTime1 / 60.0f;
            text = "Все задания по пуску устройства выполнены верно, получен допуск к работе." +
                "\nВремя выполнения: " + endTime.ToString() + " мин";
            resultPusk.text = text;

        }
        else
        {
            foreach (string i in Measure1.PuskRes)
            {
                text2 = text2 + i + "\n";
            }
            resultPr.text = text2;

            endTime = Measure1.endTime1 / 60.0f;
            text = "Были допущены ошибки, необходимо пройти обучение заново." +
                "\nВремя выполнения: " + endTime.ToString() + " мин";
            resultPusk.text = text;
        }
    }
}