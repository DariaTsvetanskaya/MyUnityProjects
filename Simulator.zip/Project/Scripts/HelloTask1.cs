﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HelloTask1 : MonoBehaviour {

    public GameObject myObject, task1Canvas;
    double Timer = 6.0;
    // Use this for initialization
    void Start () {
        task1Canvas.gameObject.SetActive(false);
    }
	
	// Update is called once per frame
	void Update () {
        if (Timer > 0)
        {
            Timer -= Time.deltaTime;
        }
        if (Timer < 0)
        {
            myObject.gameObject.SetActive(false);
            task1Canvas.gameObject.SetActive(true);
        }
    }
}
