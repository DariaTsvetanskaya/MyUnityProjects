﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Up : MonoBehaviour {
    public GameObject player;
    Vector3 startPos;
    // Use this for initialization
    void Start () {
    }
	
	// Update is called once per frame
	void Update () {
        

    }
    public void MoveUp1(){
        startPos = player.transform.position;
        startPos.x = 13.0f;
        startPos.y = 10.5f;
        startPos.z = 23.0f;
        player.transform.position = startPos;
    }
    public void MoveUp2()
    {
        startPos = player.transform.position;
        startPos.x = -30.6f;
        startPos.y = 10.5f;
        startPos.z = 23.0f;
        player.transform.position = startPos;
    }
}
