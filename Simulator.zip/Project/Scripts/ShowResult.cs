﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using UnityEngine.UI;
using System.Linq;

public class ShowResult : MonoBehaviour
{
    public Text resultPr, resultPusk;
    float endTime = 0.0f;
    private string text = "", text2 = "";
    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    {

    }   
    public void AddResult()
    {
        bool equal = Measure.Check.SequenceEqual(Measure.AllResult);
        if (equal == true)
        {
            endTime = Measure.endTime / 60.0f;
            text = "Все задания по приему устройства выполнены верно, получен допуск к работе." + 
                "\nВремя выполнения: " + endTime.ToString() + " мин";
            resultPr.text = text;

        }
        else
        {
            foreach (string i in Measure.AllResult)
            {
                text2 = text2 + i + "\n";
            }
            resultPusk.text = text2;
            endTime = Measure.endTime / 60.0f;
            text = "Были допущены ошибки, необходимо пройти обучение заново." +
                "\nВремя выполнения: " + endTime.ToString() + " мин";
            resultPr.text = text;
        }
    }
}