﻿//using System.Collections;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
using System.IO;
using System;

public class MenuTask1 : MonoBehaviour
{

    public Text answersText, checkText, fineText;
    //переменная для штрафов
    public int fine;
    public string taskResult;
    private string display = "";
    //переменная для вывода списка возможных ответов
    private bool callMe;
    public Button button1, button2, button3, button4, button5, ready;
    //public int level;
    // Create a list of parts.
    //список для вывода списка допустимых ответов
    List<string> Answers = new List<string>
        {
            "1. Составление акта готовности трубопровода",
            "2. Проверка состония запорной арматуры улов приема на линейной части " +
                "трубопровода на предмет Открыто/Закрыто",
            "3. Перевод направления потока через камеру приема",
            "4. Установка предупреждающих знаков",
            "5. Сообщение о готовности ТП ответственному за проведение работ лицу"
        };
    //список для записи ответов пользователя
    List<string> Check = new List<string>
    {

    };
    //список верной последовательности для сравнения 
    List<string> Right = new List<string>
    {
        "3",
        "2",
        "1",
        "5",
        "4"
    };
    //список для записи результатов всего обучения
    public static List<string> AllResult = new List<string>
    {
        "Результаты",
        //1
        "",
        //2
        "",
        //3
        "",
        //4
        "",
        //5
        "",
        //6
        "",
        //7
        "",
        //8
        "",
        //9
        "",
        //10
        "",
        //11
        ""
    };
    //список для записи результатов всего обучения
    public static List<string> AllResult1 = new List<string>
    {
        "Результаты",
        //1
        "",
        //2
        "",
        //3
        "",
        //4
        "",
        //5
        "",
        //6
        "",
        //7
        "",
        //8
        "",
        //9
        ""
    };
    // Use this for initialization
    void Start()
    {
        callMe = true;
        button1.onClick.AddListener(Button1OnClick);
        button2.onClick.AddListener(Button2OnClick);
        button3.onClick.AddListener(Button3OnClick);
        button4.onClick.AddListener(Button4OnClick);
        button5.onClick.AddListener(Button5OnClick);
        ready.onClick.AddListener(Ready);
    }

    void Button1OnClick()
    {
        if (button1.interactable)
        {
            Check.Add(button1.GetComponentInChildren<Text>().text);
            button1.interactable = false;
        }
    }
    void Button2OnClick()
    {
        if (button2.interactable)
        {
            Check.Add(button2.GetComponentInChildren<Text>().text);
            button2.interactable = false;
        }
    }
    void Button3OnClick()
    {
        if (button3.interactable)
        {
            Check.Add(button3.GetComponentInChildren<Text>().text);
            button3.interactable = false;
        }
    }
    void Button4OnClick()
    {
        if (button4.interactable)
        {
            Check.Add(button4.GetComponentInChildren<Text>().text);
            button4.interactable = false;
        }
    }
    void Button5OnClick()
    {
        if (button5.interactable)
        {
            Check.Add(button5.GetComponentInChildren<Text>().text);
            button5.interactable = false;
        }
    }


    //вывод результата функция для кнопки "готово"
    void Ready()
    {
        bool equal = Check.SequenceEqual(Right);
        if (equal == true)
        {
            fine = 0;
            fineText.text = "Штраф: " + fine.ToString();
        }
        else
        {
            fine = 500;
            fineText.text = "Штраф: " + fine.ToString();
        }
        taskResult = "Штраф: " + fine.ToString();
        AllResult.Add(taskResult);
        /*string output = string.Join(" ", Check.ToArray());
        WriteGazFile(output);
        string resultString = "Штраф: " + fine.ToString();
        WriteResultFile(resultString);*/
    }

    // Update is called once per frame
    void Update()
    {
        if (callMe)
        {
            AddAnswers();
            callMe = false;
        }
    }
    //вывод вариантов ответов
    void AddAnswers()
    {
        foreach (string i in Answers)
        {
            display = display.ToString() + i.ToString() + "\n" + "\n";
        }
        answersText.text = display;
    }


    //функция записи в файл запись в файл
    void WriteGazFile(string text)
    {
        if (!Directory.Exists("Save"))
        {
            Directory.CreateDirectory("Save");
        }


        if (!File.Exists("Save/menutask1.txt"))
        {
            File.Create("Save/menutask1.txt");
        }

        File.WriteAllText("Save/menutask1.txt", text);
        //System.IO.File.WriteAllLines("Save/menutask1.txt", lines);
    }
}


