﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rotate : MonoBehaviour {
    //Quaternion originRotation;
    //float angle;
    // Use this for initialization


    void Start () {
	}
	
    void OnMouseOver()
    {
        Quaternion rotationY = Quaternion.AngleAxis(1, Vector3.up);
        transform.rotation *= rotationY;
    }
}
 