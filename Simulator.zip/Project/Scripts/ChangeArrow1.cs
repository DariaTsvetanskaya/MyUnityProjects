﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ChangeArrow1 : MonoBehaviour {

    public GameObject Arrow8, Arrow81, ArrowRed8, ArrowRed81,
    Arrow9, Arrow91, Arrow911, ArrowRed9, ArrowRed91, ArrowRed911,
    Arrow11, Arrow12, ArrowRed11, ArrowRed12,
    Arrow101, Arrow1011, ArrowRed101, ArrowRed1011;
    // Use this for initialization
    void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    public void OpenUp7() {
        ArrowRed8.SetActive(false);
        ArrowRed81.SetActive(false);
        Arrow8.SetActive(true);
        Arrow81.SetActive(true);

        ArrowRed9.SetActive(false);
        ArrowRed91.SetActive(false); 
        ArrowRed911.SetActive(false);
        Arrow9.SetActive(true);
        Arrow91.SetActive(true);
        Arrow911.SetActive(true);
    }
    public void Close2() {
        //ArrowRed11.SetActive(false);
        //ArrowRed12.SetActive(false);
        //Arrow11.SetActive(true);
        //Arrow12.SetActive(true);

        ArrowRed101.SetActive(true);
        ArrowRed1011.SetActive(true);
        Arrow101.SetActive(false);
        Arrow1011.SetActive(false);
    }
    public void Open4() {
        ArrowRed11.SetActive(false);
        ArrowRed12.SetActive(false);
        Arrow11.SetActive(true);
        Arrow12.SetActive(true);
    }
    public void Open2() {
        ArrowRed101.SetActive(false);
        ArrowRed1011.SetActive(false);
        Arrow101.SetActive(true);
        Arrow1011.SetActive(true);
    }
    public void Close7() {
        ArrowRed8.SetActive(true);
        ArrowRed81.SetActive(true);
        Arrow8.SetActive(false);
        Arrow81.SetActive(false);
    }
    public void Close4() {
        ArrowRed11.SetActive(true);
        ArrowRed12.SetActive(true);
        Arrow11.SetActive(false);
        Arrow12.SetActive(false);
    }
}
