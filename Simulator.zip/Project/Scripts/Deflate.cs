﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Deflate : MonoBehaviour {

    public Button deflate;
    public GameObject level;
    Vector3 startPos;
    // Use this for initialization
    void Start () {
        deflate.onClick.AddListener(Action);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
    public void Action() {
        deflate.interactable = false;
        startPos = level.transform.position;
        startPos.y -= 0.8f;
        level.transform.position = startPos;
    }
}
